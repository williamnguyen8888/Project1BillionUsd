create view customer_view as
select `classicmodels`.`customers`.`customerName` AS `customerName`,
       `classicmodels`.`customers`.`country`      AS `country`,
       `classicmodels`.`customers`.`creditLimit`  AS `creditLimit`
from `classicmodels`.`customers`;

